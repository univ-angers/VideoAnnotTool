package com.master.info_ua.videoannottool;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.master.info_ua.videoannottool.adapter.SpinnerAdapter;
import com.master.info_ua.videoannottool.dialog.DialogAddSubCategorie;
import com.master.info_ua.videoannottool.dialog.DialogEditCategorie;
import com.master.info_ua.videoannottool.dialog.DialogEditSubCategorie;
import com.master.info_ua.videoannottool.util.Categorie;
import com.master.info_ua.videoannottool.util.Util;

import java.util.ArrayList;
import java.util.List;

import static com.master.info_ua.videoannottool.MainActivity.READ_CATEGORY_CODE;

public class CategoryActivity extends Activity implements DialogEditCategorie.EditCategoryDialogListener, DialogAddSubCategorie.AddSubCategoryDialogListener, DialogEditSubCategorie.EditSubCategoryDialogListener{

    private ListView lv_category;
    private ListView lv_sub_category;
    private ArrayAdapter<Categorie> spinnerAdapter;
    private ArrayAdapter<Categorie> spinnerAdapter2;
    private EditText ed_cat_title;
    private Button btn_valider;

    //Les catégories envoyées dans le mainActivity
    private ArrayList<String> list_categorie;

    //Les sous-catégories envoyées dans le mainActivity
    private ArrayList<CatSubCatItem> list_sous_categorie;

    //Item à récupérer pour la recréer dans le mainActivity
    static class CatSubCatItem{
        String cat;
        String subCat;

        protected CatSubCatItem(String categorie, String subCategorie) {
            cat=categorie;
            subCat=subCategorie;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        lv_category=(ListView) findViewById(R.id.lv_category);
        lv_sub_category=(ListView) findViewById(R.id.lv_sub_category);
        ed_cat_title = (EditText) findViewById(R.id.ed_cat_title);
        btn_valider = (Button) findViewById(R.id.btnValiderCat);
        list_categorie=new ArrayList<String>();
        list_sous_categorie=new ArrayList<>();

        btn_valider.setOnClickListener(btn_Listener);

        List<Categorie> categorieList=new ArrayList<>();
        categorieList.add(new Categorie("Catégorie", null, "/"));
        categorieList.addAll(Util.setCatSpinnerList(this));
//        System.out.println(getIntent().toString());
        categorieList = getIntent().getParcelableArrayListExtra("categorieList");
        System.out.println(categorieList.size());
//        spinnerAdapter = new SpinnerAdapter(this, android.R.layout.simple_spinner_item, categorieList);
//
//        List<Categorie> spinnerList2 = new ArrayList<>();
//        spinnerList2.add(new Categorie("Sous-catégorie", null, "/"));
//        spinnerAdapter2 = new SpinnerAdapter(this, android.R.layout.simple_spinner_item, spinnerList2);
//
//        lv_category.setAdapter(spinnerAdapter);
//        lv_sub_category.setAdapter(spinnerAdapter2);
//
//        lv_category.setOnItemClickListener(CategoryListener);
//        registerForContextMenu(lv_category);
//        registerForContextMenu(lv_sub_category);
    }

    protected View.OnClickListener btn_Listener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            list_categorie.add(ed_cat_title.getText().toString());
            spinnerAdapter.add(new Categorie(ed_cat_title.getText().toString(),null,"/"));
            ed_cat_title.setText("");
        }
    };

    protected AdapterView.OnItemClickListener CategoryListener= new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Categorie c = (Categorie) parent.getItemAtPosition(position);
            List<Categorie> spinnerList2=new ArrayList<>();
//            Doit on conserver les catégories de bases car ce sont des enum class déjà présent dans la globalité du code ?
            spinnerList2.addAll(Util.setSubCatSpinnerList(c.getPath()));
            System.out.println(list_sous_categorie.size());

            for(int i=0;i<list_sous_categorie.size();i++) {
                System.out.println(list_sous_categorie.get(i).cat +"     "+ list_sous_categorie.get(i).subCat);
                if (c.getName().matches(list_sous_categorie.get(i).cat)) {
                    spinnerList2.add(new Categorie(list_sous_categorie.get(i).subCat, list_sous_categorie.get(i).cat, "/" + list_sous_categorie.get(i).cat + "/" + list_sous_categorie.get(i).subCat));
                }
            }
            spinnerAdapter2 = new SpinnerAdapter(view.getContext(), android.R.layout.simple_spinner_item, spinnerList2);
            lv_sub_category.setAdapter(spinnerAdapter2);
        }
    };

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (v.getId() == R.id.lv_category) {
            MenuInflater inflater = this.getMenuInflater();
            inflater.inflate(R.menu.context_menu, menu);
            menu.findItem(R.id.edit_item_annot).setVisible(false);
            menu.findItem(R.id.delete_item_annot).setVisible(false);
            menu.findItem(R.id.add_item).setVisible(true);
            menu.findItem(R.id.edit_item).setVisible(true);
            menu.findItem(R.id.delete_item).setVisible(true);
        }
        if (v.getId() == R.id.lv_sub_category) {
            MenuInflater inflater = this.getMenuInflater();
            inflater.inflate(R.menu.context_menu_sub_cat, menu);
        }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Categorie categorie = spinnerAdapter.getItem(info.position);
        switch (item.getItemId()) {
            case R.id.add_item:
                DialogAddSubCategorie addSubCategorie = new DialogAddSubCategorie(this,categorie);
                addSubCategorie.showDialogEdit();
                return true;
            case R.id.edit_item:
                DialogEditCategorie editCategorie = new DialogEditCategorie(this, categorie);
                editCategorie.showDialogEdit();
                return true;
            case R.id.delete_item:
                categorie = spinnerAdapter.getItem(info.position);
                spinnerAdapter.remove(categorie);
                return true;
            case R.id.edit_sub_cat_item:
                categorie = spinnerAdapter2.getItem(info.position);
                DialogEditSubCategorie editSubCategorie = new DialogEditSubCategorie(this, categorie);
                editSubCategorie.showDialogEdit();
                return true;
            case R.id.delete_sub_cat_item:
                categorie = spinnerAdapter2.getItem(info.position);
                list_sous_categorie.remove(findSubCat(list_sous_categorie,categorie.getName()));
                spinnerAdapter2.remove(categorie);
                return true;

            default:
                return super.onContextItemSelected(item);
        }
    }


    public void CategoryResult(View view) {
        Intent returnintent = new Intent();
        returnintent.putExtra("Categorie", list_categorie);
//        returnintent.putParcelableArrayListExtra("Sous-categorie", list_sous_categorie);
        setResult(READ_CATEGORY_CODE, returnintent);
        finish();
    }

    @Override
    public void onSaveEditCategorie(Categorie categorie, String title) {
        for (int i=0;i<list_categorie.size();i++)
        {
            if (list_categorie.get(i).matches(categorie.getName()))
            {
                list_categorie.set(i,title);
            }
        }
        categorie.setName(title);
        spinnerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onSaveAddSubCategory(Categorie categorie,String title) {
        CatSubCatItem item=new CatSubCatItem(categorie.getName(),title);
        list_sous_categorie.add(item);
        spinnerAdapter2.add(new Categorie(title,categorie.getParentName(),"/"+categorie.getPath()+title));
        spinnerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onSaveEditSubCategorie(Categorie categorie, String title) {
        CatSubCatItem item = new CatSubCatItem(categorie.getName(),title);
        for (int i=0;i<list_sous_categorie.size();i++)
        {
            if (list_sous_categorie.get(i).subCat.matches(categorie.getName()))
            {
                System.out.println("Modifié tttt   ");
                list_sous_categorie.set(i,item);
            }
        }
        categorie.setName(title);
        spinnerAdapter2.notifyDataSetChanged();
    }

    public CatSubCatItem findSubCat( List<CatSubCatItem> liste, String s){
        for(int i=0; i<liste.size();i++){
            if (liste.get(i).subCat.matches(s)){
                return liste.get(i);
            }
        }
        return null;
    }
}