package com.master.info_ua.videoannottool.annotation;

public enum AnnotationType {
    TEXT,
    AUDIO,
    DRAW,
    ZOOM,
    SLOWMOTION
}
